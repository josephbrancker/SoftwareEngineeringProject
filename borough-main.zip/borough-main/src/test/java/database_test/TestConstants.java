package test.java.database_test;

/**
 * Class to store constants used in JUnit testing
 *
 * @author Elijah Burke
 */
public class TestConstants {

  public static final String TEST_LISTINGS_FILE = "src/test/resources/listingstest.json";
}
