# __Borough__
---
Borough is an application that allows students and parents at the University of South Carolina to find local student housing that's right for them.

Because we're Team Badger.
Badgers live in burrows.
Burrow? Borough? Homophone.
